package com.cg.mobilerechargeapp.test;

import org.junit.Assert;
import org.junit.Test;

import com.cg.mobilerechargeapp.exception.AccountException;
import com.cg.mobilerechargeapp.service.AccountService;
import com.cg.mobilerechargeapp.service.AccountServiceImpl;



public class TestClass {
    AccountService service = new AccountServiceImpl();
    boolean result;
    @Test(expected=AccountException.class)
    public void test_validateMobileNo_Null()throws AccountException{
        result = service.validateMobileNo(null);
        
    }
    
    @Test
    public void test_ValidateMobileNo_v1()throws AccountException{
        result = service.validateMobileNo("0123456789");
        Assert.assertEquals(false, result);
        
    }
    
    
    @Test
    public void test_ValidateMobileNo_v2()throws AccountException{
        result = service.validateMobileNo("8912434354dsf");
        Assert.assertEquals(false, result);
        
    }
    
    @Test
    public void test_ValidateMobileNo_v3()throws AccountException{
        result = service.validateMobileNo("8978063079");
        Assert.assertEquals(true, result);
        
    }
    
    
    @Test(expected=AccountException.class)
    public void test_ValidateRechargeAmount_Null()throws AccountException{
        result = service.validateRechargeAmount(null);
        Assert.assertEquals(false, result);
    }
    
    
    @Test
    public void test_ValidateRechargeAmount_v1()throws AccountException{
        result = service.validateRechargeAmount(250.0);
        Assert.assertEquals(true, result);
    }
    
    @Test
    public void test_ValidateRechargeAmount_v2()throws AccountException{
        result = service.validateRechargeAmount(624570000000.0);
        Assert.assertEquals(false, result);
    }
    
    @Test
    public void test_ValidateRechargeAmount_v3()throws AccountException{
        result = service.validateRechargeAmount(3.0);
        Assert.assertEquals(false, result);
    }

    @Test
    public void test_ValidateRechargeAmount_v4()throws AccountException{
        result = service.validateRechargeAmount(960.489631);
        Assert.assertEquals(false, result);
    }
    @Test
    public void test_ValidateRechargeAmount_v5()throws AccountException{
        result = service.validateRechargeAmount(25.0);
        Assert.assertEquals(true, result);
    }

}
