package com.cg.mobilerechargeapp.exception;

@SuppressWarnings("serial")
public class AccountException extends Exception{
	public AccountException(String msg) {
		super(msg);
	}
	

}
