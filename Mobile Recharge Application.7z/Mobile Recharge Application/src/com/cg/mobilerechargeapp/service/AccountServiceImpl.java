package com.cg.mobilerechargeapp.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mobilerechargeapp.dao.AccountDao;
import com.cg.mobilerechargeapp.dao.AccountDaoImpl;
import com.cg.mobilerechargeapp.dto.Account;
import com.cg.mobilerechargeapp.exception.AccountException;

public class AccountServiceImpl implements AccountService{
	AccountDao dao;
	public AccountServiceImpl() {
		super();
		dao= new AccountDaoImpl();
		
		
	}
	public double rechargeAccount(String mobileNo, double rechargeAmount) {
		
		try {
			return dao.rechargeAccount(mobileNo, rechargeAmount);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rechargeAmount;
		
	}
	@Override
	public Account getAccountDetails(String mobile) {
		// TODO Auto-generated method stub
		try {
			return dao.getAccountDetails(mobile);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public boolean validateMobileNo(String mobileNo)
            throws AccountException {
        // TODO Auto-generated method stub
        if(mobileNo == null)
            throw new AccountException("Null value found");
        Pattern p = Pattern.compile("[6789][0-9]{9}");
        Matcher m = p.matcher(mobileNo);
        return m.matches();
    }

    @Override
    public boolean validateRechargeAmount(Double rechargeAmount)
            throws AccountException {
        // TODO Auto-generated method stub
        if(rechargeAmount == null)
            throw new AccountException("Null value found");
        
        String ra = rechargeAmount.toString();
        return (ra.matches("\\d{2,9}\\.\\d{0,4}"));
    }
	
	

}
